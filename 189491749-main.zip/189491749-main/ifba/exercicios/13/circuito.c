/*Um circuito elétrico é composto de duas resistências R1 e R2 em paralelo, e ambas em
sequência de uma resistência R3. Faça um algoritmo para calcular a resistência
equivalente desse circuito.*/

#include <stdio.h>

int main(void)
{
    printf(")
}
