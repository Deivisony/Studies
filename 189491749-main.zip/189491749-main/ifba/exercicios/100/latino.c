/*Verificar se uma matriz dada forma um Quadrado Latino de ordem N, no qual
em cada linha e em cada coluna aparecem todos os inteiros 1,2,3, ... N, ou seja, cada linha
ou coluna é permutação dos N primeiros números inteiros.*/

#include <stdio.h>

int main(void)
{
    int quadradoL



    printf("Teste");

}
